#include <bits/stdc++.h>
using namespace std;
const int MAX= 20 ;
#define VoCuc - 1
struct GRAPH{
int n;
int a[MAX][MAX];
};
bool ThuocT[MAX];
int Length[MAX];
int LastV[MAX];

void  readGRAPH (GRAPH &g){
	
	ifstream is;
	is.open("text5.TXT");
	if (is.is_open()){	
		is>>g.n;
		for(int i=0;i<g.n;i++){
		for(int j=0 ;j<g.n;j++ ){
			is>>g.a[i][j];
		}
	}
	is.close();	
	}
	else cout<<"Khong mo duoc file!";	
}
void Dijkstra(GRAPH g, int x, int y){
	int min = -1;
	int i;
	for(i = 0; i < g.n; i++){
	ThuocT[i] = true;
	Length[i] = VoCuc;
	LastV[i] = -1;
	}
	Length[x] = 0;
	ThuocT[x] = false;
	LastV[x] = x;

	int v = x;
	int t = x;
	while(ThuocT[y]){
		for(int k = 0; k < g.n; k++){
			if(g.a[v][k] != 0 && ThuocT[k] == true && (Length[k] == VoCuc || Length[k] > Length[v] + g.a[v][k])){
				Length[k] = Length[v] + g.a[v][k];
				LastV[k] = v;
			}
		}
	v = -1;
	for(i = 0; i < g.n; i++){
		if(ThuocT[i] == true && Length[i] != VoCuc)
			if(v == -1 || Length[v] > Length[i])
				v = i;
	}
	ThuocT[v] = false;

	}
}

void Xuat(int x, int y){
	int DuongDi[MAX];
	int v = y, i;
	
	int id = 0;
	while (v != x){
		DuongDi[id] = v;
		v = LastV[v];
		id++;
	}
	DuongDi[id] = x;
	for(i = id; i > 0; i--)
		cout<<DuongDi[i]<<" -->";
	cout<<DuongDi[i]<<endl;
}
void xuatfile(int x , int y){
	ofstream os;
	os.open("output.txt");
	if (os.is_open()){	
		os<<"Duong di ngan nhat tu "<<x<<" den "<<y<<" la:"<<endl;
		int DuongDi[MAX];
		int v = y, i;
	
		int id = 0;
		while (v != x){
		DuongDi[id] = v;
		v = LastV[v];
		id++;
	}
		DuongDi[id] = x;
	for(i = id; i > 0; i--)
		os<<DuongDi[i]<<" -->";
		os<<DuongDi[i]<<endl;
	
		os<<"Tong duong di: "<<Length[2];	
	os.close();
	
		
	}

}
int main(){
	GRAPH g;
	readGRAPH(g);
	int x, y;
	cout<<"Nhap dinh dau: "; cin>>x;
	cout<<"Nhap dinh cuoi: "; cin>>y;
	Dijkstra(g, x, y);
	cout<<"Duong di ngan nhat tu "<<x<<" den "<<y<<" la:"<<endl;
	Xuat(x, y);
	// Cau 3
	cout<<"Tong duong di: "<<Length[2];
	//Cau 4
	xuatfile(x,y);
	return 0;
}

//Cau 1
//	Giai thich 
//  <1> kiem tra coi la cai minh dang xet da thuoc T (Do Thi) hay chua
//  <2> Dung de luu tong duong di ma no da di qua , dung no de xet coi duong di nao ngan nhat
//	<3> Luu Vet nhung diem da di qua ( ngan nhat)

//Cau 2
//	begin ... end
//	<4> nam o Buoc 1 : khoi tao, gan gia tri vao cac bien
//	<6> nam o Buoc 2&3 : So sanh 2 duong di(so cai ngan hon) roi cong lai nhung cai da chon
//	<7> nam o Buoc 4 : So sanh 2 duong di , chon cai nho hon sau do danh cai da chon

