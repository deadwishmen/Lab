#include<bits/stdc++.h>

using namespace std;

const int MAX = 100;

struct GRAPH{
	int a[MAX][MAX];
	int n;
	int visited[MAX];
	int LuuViet[MAX];
};
int Stack[MAX];
int Last=0;
void readGRAPH(GRAPH& g){
	ifstream f;
	f.open("test4.TXT");
	if(f.is_open()){
		f>>g.n;
		for(int i=0; i<g.n; i++){
			for(int j=0; j<g.n; j++){
				f>>g.a[i][j];
			}
		}
		f.close();
	}
	else cout << "khong mo duoc file";
}
void printGRAPH (GRAPH g){
	cout << "So dinh cua do thi: " << g.n << "\n";
	for(int i=0; i<g.n;i++){
		for(int j=0; j<g.n;j++){
			cout << setw(4) << g.a[i][j];
		}
		cout << "\n";
	}
}
// dequy DFS
void DFS(int s, GRAPH& g){
	g.visited[s] = 1;
	for(int i=0; i<g.n; i++){
		if((g.visited[i]==0) && (g.a[s][i]!=0)){
			g.LuuViet[i]=s;
			DFS(i,g);
		}
	}
}
// Queue DFS
void Push(int x){
	Last++;
	Stack[Last]=x;
}
int Pop(){
	int x = Stack[Last];
	Last--;
	return x;
}
void DFSStack(int S, GRAPH& g){
	int u;
	Push(S);
	g.visited[S]=1;
	do{
		u=Pop();
		for(int i=0; i<g.n; i++){
			if((g.visited[i]==0) && (g.a[u][i]!=0)){
				g.visited[i]=1;
				g.LuuViet[i]=u;
				Push(u);
				Push(i);
			}
		}
	}while(Last!=0);
}

void duyetDFS(int s, int f, GRAPH& g){
	for(int i=0; i<g.n; i++){
		g.visited[i]=0;
		g.LuuViet[i]=-1;
	}
	DFSStack(s,g);
//	 cout << g.visited[];
	if(g.visited[f]==1){
		int i=f;
		while(i!=s){
			cout << i << "<--";
			 i=g.LuuViet[i];
		}
		cout << s;
		cout << "\n";
	}else{
		cout << "ko co duong di tu dinh";
	}
}
int main(){
	GRAPH g;
	readGRAPH(g);
	printGRAPH(g);
	duyetDFS(1,2,g);
	return 0;
}
