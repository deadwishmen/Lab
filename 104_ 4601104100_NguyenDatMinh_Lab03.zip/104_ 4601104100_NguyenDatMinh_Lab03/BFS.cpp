#include<bits/stdc++.h>

using namespace std;

const int MAX = 100;

struct GRAPH{
	int a[MAX][MAX];
	int n;
	int visited[MAX];
	int LuuViet[MAX];
};
int Queue[MAX];
int Last, First;
void readGRAPH(GRAPH& g){
	ifstream f;
	f.open("test4.TXT");
	if(f.is_open()){
		f>>g.n;
		for(int i=0; i<g.n; i++){
			for(int j=0; j<g.n; j++){
				f>>g.a[i][j];
			}
		}
		f.close();
	}
	else cout << "khong mo duoc file";
}
void printGRAPH (GRAPH g){
	cout << "So dinh cua do thi: " << g.n << "\n";
	for(int i=0; i<g.n;i++){
		for(int j=0; j<g.n;j++){
			cout << setw(4) << g.a[i][j];
		}
		cout << "\n";
	}
}
void Push(int v){
	Last++;
	Queue[Last]=v;
}
int Pop(){
	int x = Queue[First];
	First++;
	return x;
}
void BFS(int s, GRAPH& g){
	int u;
	Queue[0]=s;
	Last = 0;
	First = 0;
	do{
		u=Pop();
		for(int i=0; i<g.n; i++){
			if(g.visited[i]==0 && g.a[u][i]!=0){
				Push(i);
				g.visited[i]=1;
				g.LuuViet[i]=u;
			}
		}
	}while(First <= Last);
}

void duyetBFS(int s, int f, GRAPH& g){
	for(int i=0; i<g.n; i++){
		g.visited[i]=0;
		g.LuuViet[i]=-1;
	}
	BFS(s,g);
//	 cout << g.visited[];
	if(g.visited[f]==1){
		int i=f;
		while(i!=s){
			cout << i << "<--";
			 i=g.LuuViet[i];
		}
		cout << s;
		cout << "\n";
	}else{
		cout << "ko co duong di tu dinh";
	}
}
int main(){
	GRAPH g;
	readGRAPH(g);
	printGRAPH(g);
	duyetBFS(1,2,g);
	return 0;
}
