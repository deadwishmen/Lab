#include<bits/stdc++.h>
#include<fstream>

using namespace std;
//#define file "E:\\code\\dev C++\\DOTHI.TXT"
// dung tong quat ko dung duoc tren dev c++

const int MAX = 100;

struct GRAPH{
	int sodinh;
	int a[MAX][MAX];
	
};
// HAM DOC DU LIEU TU FILE
void readGRAPH(string file ,GRAPH& g){
	ifstream f;
	f.open("DOTHI.TXT");
	if(f.is_open()){
		f>>g.sodinh;
		for(int i=0; i<g.sodinh; i++){
			for(int j=0; j<g.sodinh; j++){
				f>>g.a[i][j];
			}
		}
		f.close();
	}
	else cout << "khong mo duoc file";
}
void printGRAPH (GRAPH g){
	cout << "So dinh cua do thi: " << g.sodinh << "\n";
	for(int i=0; i<g.sodinh;i++){
		for(int j=0; j<g.sodinh;j++){
			cout << setw(4) << g.a[i][j];
			
		}
		cout << "\n";
	}
}
int KiemTraMaTranKeHopLe (GRAPH& g){
	for(int i=0; i<g.sodinh;i++)
		if(g.a[i][i] != 0)
			return 0;
	return 1;
}
int KiemTraDoThiVoHuong (GRAPH& g){
	for(int i=0; i<g.sodinh;i++){
		for(int j=i+1;j<g.sodinh;j++){
			if(g.a[i][j]!=g.a[j][i]){
				return 0;
			}
			
		}
	}
	return 1;
}
int getSoCanh(GRAPH& g){
	int tong =0;
	for(int i=0;i<g.sodinh;i++){
		for(int j=0;j<g.sodinh;j++){
			if(g.a[i][j]!=0){
				tong++;
			}
		}
	}
	if(KiemTraDoThiVoHuong(g)){
		return tong/2;
	}else{
		return tong;
	}
}
void getBacDinhDTVH(GRAPH g){
	int count = 0;
	for(int i=0; i<g.sodinh;i++){
		if(g.a[i][i]!=0){
			count+= g.a[i][i];
		}
		for(int j=0; j<g.sodinh; j++){
			if(g.a[i][j] <= 1 ){
				if(g.a[i][j]!=0){
					count++;
				}
			}else{
				if(g.a[i][j]!=0){
					count+= g.a[i][j];
				}
			}
		}
		cout << "deg" << i + 1 << ":"<< setw(3)<< count << "\n";
		count=0;
	}
}
void getBacDinhDTCH(GRAPH g){
	int count1=0;
	int count2=0;
	int tong1=0;
	int tong2=0;
	for(int i=0; i<g.sodinh;i++){
		for(int j=0; j<g.sodinh;j++){
			if(g.a[i][j] !=0){
				count1++;
			}
			if(g.a[j][i]!=0){
				count2++;
			}
		}
		tong1+=count1;
		cout << "deg+" << "("<< i +1 << ")=" <<" "<< count1 << "  ";
		tong2+=count2;
		cout  << "deg-" << "("<< i +1 << ")=" <<" "<< count2 << "\n";
		count1=0;
		count2=0;
	}
	cout <<"tong"<< setw(6) << tong1 << setw(12) << tong2;
	
}
void getBacLonNhat (GRAPH g, int c[100]){
	int max=0;
	int min=99999;
	int count = 0;
	for(int i=0; i<g.sodinh;i++){
		if(g.a[i][i]!=0){
			count+= g.a[i][i];
		}
		for(int j=0; j<g.sodinh; j++){
			if(g.a[i][j] <= 1 ){
				if(g.a[i][j]!=0){
					count++;
				}
			}else{
				if(g.a[i][j]!=0){
					count+= g.a[i][j];
				}
			}
		}
		c[i]=count;
		if(c[i]%2==0){
			cout << "dinh " << i+1 << " la bat le" << "\n"; 
		}else{
			cout << "dinh " << i+1 << " la bat chan" << "\n";
		}
		if(c[i]>max){
			max=c[i];
		}
		if(c[i]<min){
			min=c[i];
		}
		count = 0;
	}
	cout << "\ncac dinh co so bat lon nhat\n";
	for(int i=0; i<g.sodinh; i++){
		if(c[i]==max){
			cout  << "dinh " << i +1<< "\n";
		}
	}
	cout<< "cac dinh co so bat nho nhat\n";
	for(int i=0 ; i<g.sodinh; i++){
		if(c[i]==min){
			cout << "dinh " << i +1<< "\n";
		}
	}
	
}
void DinhCoLapDinhTreo(GRAPH g){
	int count=0;
	for(int i=0; i<g.sodinh;i++){
		if(g.a[i][i]!=0){
			count+= g.a[i][i];
		}
		for(int j=0; j<g.sodinh; j++){
			if(g.a[i][j] <= 1 ){
				if(g.a[i][j]!=0){
					count++;
				}
			}else{
				if(g.a[i][j]!=0){
					count+= g.a[i][j];
				}
			}
		}
		if(count == 1){
			cout << "dinh " << i+1 << " la dinh treo\n";
		}
		if(count ==0){
			cout << "dinh " << i+1 << " la dinh co lap\n";
		}
		count =0;
	}
}

int main(){
	string file;
	int a[MAX];
	GRAPH g;
	readGRAPH(file, g);
	printGRAPH(g);
	if(!KiemTraMaTranKeHopLe(g)){
		cout << "ma tran ko hop le";
	}else{
		cout << "ma tran hop le";
	}
	cout << "\n";
	if(!KiemTraDoThiVoHuong(g)){
		cout << "co huong";
	}else{
		cout << "vo huong";
	}
	cout << "\n";
	cout << "so canh: " << getSoCanh(g);
	cout << "\n";
	cout << "bat cua tat ca cac dinh\n";
	if(!KiemTraDoThiVoHuong(g)){
		getBacDinhDTCH(g);
	}else{
		getBacDinhDTVH(g);
		cout << "\n";
		getBacLonNhat(g,a);
		cout << "\n";
		DinhCoLapDinhTreo(g);
	}
	return 0;
}
