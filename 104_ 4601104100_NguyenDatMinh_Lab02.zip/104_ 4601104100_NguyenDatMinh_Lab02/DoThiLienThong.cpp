#include<bits/stdc++.h>
#include<fstream>

using namespace std;
//#define file "E:\\code\\dev C++\\DOTHI.TXT"
// dung tong quat ko dung duoc tren dev c++

const int MAX = 100;

struct GRAPH{
	int sodinh;
	int a[MAX][MAX];
};
int visited[MAX];
int nSoMienLienThong;

// HAM DOC DU LIEU TU FILE
void readGRAPH(string file ,GRAPH& g){
	ifstream f;
	f.open("test3.TXT");
	if(f.is_open()){
		f>>g.sodinh;
		for(int i=0; i<g.sodinh; i++){
			for(int j=0; j<g.sodinh; j++){
				f>>g.a[i][j];
			}
		}
		f.close();
	}
	else cout << "khong mo duoc file";
}
void printGRAPH (GRAPH g){
	cout << "So dinh cua do thi: " << g.sodinh << "\n";
	for(int i=0; i<g.sodinh;i++){
		for(int j=0; j<g.sodinh;j++){
			cout << setw(4) << g.a[i][j];
			
		}
		cout << "\n";
	}
}

void visit(GRAPH g, int i, int nLabel){
	visited[i]=nLabel;
	for(int j=0; j<g.sodinh; j++){
		if(visited[j]==0 && (g.a[i][j] !=0)){
			visit(g, j, nLabel);
		}
	}
}
void XetLienThong(GRAPH& g){
	for(int i=0; i<g.sodinh;i++){
		visited[i]=0;
	}
	nSoMienLienThong = 0;
	for(int i=0; i<g.sodinh; i++){
		if(visited[i]==0){
			nSoMienLienThong++;
			visit(g,i,nSoMienLienThong);
		}
		
	}
}

void InThanhPhanLienThong(GRAPH g){
	cout << "So mien lien thong: " << nSoMienLienThong << "\n";
	if(nSoMienLienThong>1){
		for(int i=1; i<=nSoMienLienThong; i++){
		cout << "Mien lien thong " << i < "\n";
		for(int j=0; j<g.sodinh; j++){
			if(visited[j]==i){
				cout << setw(4)<<j;
			}
		}
		cout << "\n";
		}
	}else{
		cout<< "do thi lien thong";
	}
	
}
int main(){
	string file;
	int a[MAX];
	GRAPH g;
	readGRAPH(file, g);
	printGRAPH(g);
	XetLienThong(g);
	InThanhPhanLienThong(g);
}
